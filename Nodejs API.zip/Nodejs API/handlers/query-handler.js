
'use strict';
const Users= require('../models/users')
const Messages= require('../models/messages')
class QueryHandler{

	constructor(){
	this.Mongodb = require("./../config/db");
	}

	getUserByUsername(username){
		return new Promise( async (resolve, reject) => {
			Users.findOne({name:username})
     .then(user=>{
            resolve(user)
        })
          .catch(err=>reject(err));
				
	})}

	makeUserOnline(userId){
	   console.log('make user online');
	   console.log('id is',userId);
				const data = {
					id : userId,
					value : {
						$set :{
							online : 'Y'
						}
					}
				};

				return new Promise( async (resolve, reject) => {
					try {
											 const dbresponse=
			await Users.updateOne({ _id : data.id},data.value);
						 resolve(dbresponse);
				
					}catch(err){
						reject(err)
					}
					
				});
}

	registerUser(data){
		return new Promise( async (resolve, reject) => {
			try {
				var name=data.username;
				var password=data.password;
				var socketId=data.socketId;
				var online=data.online;
				Users.findOne({name:name})
				.then(user=>{
			
					if(user){
						 resolve('user exists already');
					}else{
					  const newUser=new Users({
						  name,
						  password,
						  socketId,
						  online
					  });
						 newUser.save()
						 .then(user=>{
							resolve(user);
						})
						.catch(err =>console.log(err));
					}
			})

			} catch (error) {
				reject(error)
			}	
		});
	}

	userSessionCheck(data){
		console.log('user session check',data);
		return new Promise( async (resolve, reject) => {
			Users.findOne({_id:data.userId,online:'Y'})
			.then(user=>{
	             resolve(user)
					})
					.catch(err =>{console.log(err)
					reject(error);
					})
		});
	}

	getUserInfo({userId,socketId = false}){
		var queryProjection = null;
		if(socketId){
			queryProjection = {

				"socketId" : true
			}
		} else {
			queryProjection = {
				"username" : true,
				"online" : true,
				'_id': false,
				'id': '$_id'
			}
		}
		return new Promise( async (resolve, reject) => {
				Users.find().then(result=>{
					socketId ? resolve(result[0]['socketId']) : resolve(result);
				}).catch(( err )=>{
						reject(err);
					})
				
		});
	}

	addSocketId({userId, socketId}){
		const data = {
			id : userId,
			value : {
				$set :{
					socketId : socketId,
					online : 'Y'
				}
			}
		};
		return new Promise( async (resolve, reject) => {
			try {
				 const dbresponse=
	await Users.updateOne({ _id : data.id},data.value);
				 resolve(dbresponse);
		
			}catch(err){
				reject(err)
			}
			
		});
	}

	getChatList(userId){
		return new Promise( async (resolve, reject) => {
				Users.aggregate([{
					$match: {
						'socketId': { $ne : userId}
					}
				},{
					$project:{
						"username" : true,
						"online" : true,
						'_id': false,
						'id': '$_id'
					}
				}
				]).then(result=>{
                    resolve(result);
				}).catch((err)=>{
					reject(err);
				})
		});
	}

	insertMessages(messagePacket){
		return new Promise( async (resolve, reject) => {
                const newMessage=new Messages(messagePacket)
				newMessage.save()
                .then(result=>{
					console.log('message sent',result)
					resolve(result)
				})
			.catch (error=> {
				console.log('error while posting message',error);
				reject(error)
			})
		});
	}

	getMessages({userId, toUserId}){
		const data = {
				'$or' : [
					{ '$and': [
						{
							'toUserId': userId
						},{
							'fromUserId': toUserId
						}
					]
				},{
					'$and': [ 
						{
							'toUserId': toUserId
						}, {
							'fromUserId': userId
						}
					]
				},
			]
		};	    
		return new Promise( async (resolve, reject) => {
				Messages.find(data).sort({'timestamp':1})
			        .then(result=>{

						resolve(result);
					})
			.catch((error)=> {
				console.log(error);
				reject(error)
			})
	
	})}

	logout(userID,isSocketId){
		const data = {
			$set :{
				online : 'N'
			}
		};

			return new Promise( async (resolve, reject) => {
				try {
					let condition = {};
			if (isSocketId) {
			 		condition.socketId = userID;
			 	}else{
			 		condition._id = userID;
			 	}
				console.log('Update LOGOUT status request');
					 const dbresponse=
		await Users.updateOne(condition,data);
					 console.log(dbresponse);
					 resolve(dbresponse);
			
				}catch(err){
					console.log(err);
					reject(err)
				}
				
			});

		}}
module.exports = new QueryHandler();
