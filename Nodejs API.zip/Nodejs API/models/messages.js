const mongoose=require('mongoose');

const msgSchema= mongoose.Schema({
    fromUserId:{
        type:String,
        required:true
 },
 message:{
   type:String,
    required:true,
 },
 toUserId:{
   type:String,
    required:true,
 },
 date:{
   type:Date,
   default:Date.now
}

});

module.exports = mongoose.model('Messages',msgSchema)